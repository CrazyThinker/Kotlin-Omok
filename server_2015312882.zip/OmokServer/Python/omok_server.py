#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 29 13:33:24 2022

@author: hsherlcok
"""

from flask import Flask
from flask import request
from flask import jsonify
from flask import render_template
from flask_socketio import SocketIO, join_room, leave_room, send
import random

# This line is for solving flask's CORS error
# You need 'pip install flask_cors' to use flask_cors
#from flask_cors import CORS
from werkzeug.serving import WSGIRequestHandler
import json
WSGIRequestHandler.protocol_version = "HTTP/1.1"

app = Flask(__name__)
app.secret_key = "OmokCommunication"

# This line is for solving flask's CORS error
#CORS(app)

users = []
rooms = {}
roommsg = {}
matchs = []

@app.route("/login", methods=['POST'])
def login():
    data = request.get_json()
    name = data.get("name")
    password = data.get("password")

    global users
    ret = {
        "login": False,
        "code": 0,
    }
    if name == "" or password == "":
        return jsonify (ret)

    for usr in users:
        if usr["name"] == name:
            if usr["password"] == password:
                ret["login"] = True
                ret["code"] = usr["code"]
            break

    # return jsonify(maze=string.decode('utf-8', 'ignore'))
    return jsonify (ret)

@app.route("/newid", methods=['POST'])
def newid():
    data = request.get_json()
    name = data.get("name")
    password = data.get("password")

    global users
    ret = {
        "success": True
    }
    if name == "" or password == "":
        return jsonify (ret)

    for usr in users:
        if usr["name"] == name:
            ret["success"] = False
            break

    if ret["success"] == True:
        rcode = random.randint(1,10000000)
        newusr = {
            "name": name,
            "password": password,
            "win": 0,
            "lose": 0,
            "code": rcode
        }
        users.append(newusr)

    # return jsonify(maze=string.decode('utf-8', 'ignore'))
    return jsonify (ret)

@app.route("/userinfo", methods=['GET'])
def userinfo():
    name = request.args.get("name")

    global users
    ret = {
        "win": -1,
        "lose": -1,
    }
    for usr in users:
        if usr["name"] == name:
            ret["win"] = usr["win"]
            ret["lose"] = usr["lose"]
            break

    # return jsonify(maze=string.decode('utf-8', 'ignore'))
    return jsonify (ret)


@app.route("/room", methods=['GET'])
def room():
    global rooms
    host = request.args.get("host")

    ret = {
        "challenger": "",
        "size": 13,
        "gamemode": 0,
        "title": ""
    }
    if host in rooms:
        ret = rooms[host]
        ret["host"] = host

    return jsonify (ret)

@app.route("/roomlist", methods=['GET'])
def roomlist():
    global rooms

    return jsonify (rooms)

    # return jsonify(maze=string.decode('utf-8', 'ignore'))

@app.route("/roomcreate", methods=['POST'])
def roomcreate():
    data = request.get_json()
    name = data.get("name")
    code = data.get("code")
    size = data.get("size")
    gamemode = data.get("gamemode")
    title = data.get("title")

    global rooms
    global users

    ret = {
        "success": False
    }

    # name과 code 검사
    for usr in users:
        if usr["name"] == name:
            if usr["code"] == code:
                break
            else:
                return jsonify (ret)

    if name not in rooms:
        rooms[name] = {"challenger": "", "size": size, "gamemode": gamemode, "title": title}
        ret["success"] = True
    return jsonify (ret)

@app.route("/roomjoin", methods=['POST'])
def roomjoin():
    data = request.get_json()
    name = data.get("name")
    code = data.get("code")
    host = data.get("host")

    global rooms
    global users

    ret = {
        "success": False
    }

    # name과 code 검사
    for usr in users:
        if usr["name"] == name:
            if usr["code"] == code:
                break
            else:
                return jsonify (ret)

    global rooms
    if host in rooms:
        if rooms[host]["challenger"] != "":
            rooms[host]["challenger"] = name
            ret["success"] = True

    return jsonify (ret)

@app.route("/roomleave", methods=['POST'])
def roomleave():
    data = request.get_json()
    name = data.get("name")
    code = data.get("code")
    host = data.get("host")

    global users
    global rooms

    ret = {
        "success": False
    }

    # name과 code 검사
    for usr in users:
        if usr["name"] == name:
            if usr["code"] == code:
                break
            else:
                return jsonify (ret)

    if host not in rooms:
        ret["success"] = False

    elif name == host:
        del rooms[host]
        ret["success"] = True

    elif name == rooms[host]["challenger"]:
        rooms[host]["challenger"] = ""
        ret["success"] = True

    return jsonify (ret)

@app.route("/matchplace", methods=['POST'])
def matchplace():
    data = request.get_json()
    name = data.get("name")
    code = data.get("code")
    host = data.get("host")
    x = data.get("x")
    y = data.get("y")

    global users
    global rooms
    global roommsg

    ret = {
        "success": False
    }

    # name과 code 검사
    for usr in users:
        if usr["name"] == name:
            if usr["code"] == code:
                break
            else:
                return jsonify (ret)

    if host not in rooms:
        ret["success"] = False

    elif name == host or name == rooms[host]["challenger"]:
        roommsg[host] = [name, "place", x, y]
        ret["success"] = True

    return jsonify (ret)

@app.route("/matchpass", methods=['POST'])
def matchpass():
    data = request.get_json()
    name = data.get("name")
    code = data.get("code")
    host = data.get("host")

    global users
    global rooms
    global roommsg

    ret = {
        "success": False
    }

    # name과 code 검사
    for usr in users:
        if usr["name"] == name:
            if usr["code"] == code:
                break
            else:
                return jsonify (ret)

    if host not in rooms:
        ret["success"] = False

    elif name == host or name == rooms[host]["challenger"]:
        roommsg[host] = [name, "pass", 0, 0]
        ret["success"] = True

    return jsonify (ret)

@app.route("/matchwin", methods=['POST'])
def matchwin():
    data = request.get_json()
    name = data.get("name")
    code = data.get("code")
    host = data.get("host")

    global users
    global rooms
    global roommsg

    ret = {
        "success": False
    }

    # name과 code 검사
    for usr in users:
        if usr["name"] == name:
            if usr["code"] == code:
                break
            else:
                return jsonify (ret)

    if host not in rooms:
        ret["success"] = False
    elif name == host:
        roommsg[host] = [name, "win", 0, 0]
        for usr in users:
            if usr["name"] == name:
                usr["win"] += 1
            elif usr["name"] == rooms[host]["challenger"]:
                usr["lose"] += 1
        ret["success"] = True
        del rooms[host]

    elif name == rooms[host]["challenger"]:
        roommsg[host] = [name, "win", 0, 0]
        for usr in users:
            if usr["name"] == name:
                usr["lose"] += 1
            elif usr["name"] == rooms[host]["challenger"]:
                usr["win"] += 1
        ret["success"] = True
        del rooms[host]

    return jsonify (ret)

@app.route("/matchmsg", methods=['POST'])
def matchmsg():
    data = request.get_json()
    name = data.get("name")
    code = data.get("code")
    host = data.get("host")

    global users
    global rooms
    global roommsg

    ret = {
        "name": "",
        "type": "",
        "x": 0,
        "y": 0
    }

    # name과 code 검사
    for usr in users:
        if usr["name"] == name:
            if usr["code"] == code:
                break
            else:
                return jsonify (ret)

    if host not in rooms or host not in roommsg:
        return jsonify (ret)
    elif name == host or name == rooms[host]["challenger"]:
        ret = roommsg[host]
        del roommsg[host]

    return jsonify (ret)

if __name__ == "__main__":
    app.run(host='localhost', port=8888)