# -*- coding: utf-8 -*-


def handler(event, context):
    return {'status': 'success'}
