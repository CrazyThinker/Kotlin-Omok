package edu.skku.cs.omok

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import java.io.IOException

class CRoomList(val title: String, val host: String, val gamemode: Int, val size: Int)
class CustomAdapterRoomList(val context: Context, val items:ArrayList<CRoomList>, val activity: WaitingRoomActivity): BaseAdapter() {
    override fun getCount(): Int {
        return items.size
    }

    override fun getItem(position: Int): Any {
        return items.get(position)
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getView(i: Int, cvtView: View?, parent: ViewGroup?): View {
        val inflater: LayoutInflater = LayoutInflater.from(context)
        val view: View = inflater.inflate(R.layout.sub_roominfo, null)

        val tvsubTitle = view.findViewById<TextView>(R.id.textViewsubTitle)
        val tvsubHost = view.findViewById<TextView>(R.id.textViewsubHost)
        val tvsubGameMode = view.findViewById<TextView>(R.id.textViewsubGameMode)
        val tvsubSize = view.findViewById<TextView>(R.id.textViewsubSize)
        val btnsubEnter = view.findViewById<Button>(R.id.buttonsubEnter)

        tvsubTitle.text = items[i].title
        tvsubHost.text = items[i].host
        if(items[i].gamemode < 0) tvsubGameMode.text = "솔로플레이"
        else if(items[i].gamemode == 1) tvsubGameMode.text = "일반 렌주룰"
        else if(items[i].gamemode == 2) tvsubGameMode.text = "오프닝 렌주룰 (Swap 룰)"
        tvsubSize.text = "${items[i].size} × ${items[i].size}"
        btnsubEnter.setOnClickListener {
            activity.RoomJoin(items[i].host)
            activity.SoloPlay = false
        }

        return view
    }
}

class WaitingRoomActivity : AppCompatActivity() {
    companion object {
        const val EXT_NAME = "user_name"
        const val EXT_CODE = "123456789"
    }

    var username = ""
    var usercode = 0
    var roomname = ""
    var userwin = -1
    var userlose = -1
    var SoloPlay = false

    fun UpdateUser() {
        val client = OkHttpClient()
        val host = "https://k8q1jmufk0.execute-api.us-east-1.amazonaws.com/dev/userinfo?name="
        val path = username

        val req = Request.Builder().url(host + path).build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                response.use{
                    if (!response.isSuccessful) throw IOException("Unexpected code $response")
                    val str = response.body!!.string()
                    val data = Gson().fromJson(str, DataUserInfoResponse::class.java)

                    CoroutineScope(Dispatchers.Main).launch {
                        this@WaitingRoomActivity.userwin = data.win!!
                        this@WaitingRoomActivity.userlose = data.lose!!
                        if(data.win!! >= 0 && data.lose!! >= 0) {
                            val TextViewRecord = findViewById<TextView>(R.id.textViewRecord)
                            TextViewRecord.text = "$username\n${data.win}승 ${data.lose}패"
                        }
                    }
                }
            }
        })
    }

    fun UpdateRoom() {
        val client = OkHttpClient()
        val host = "https://k8q1jmufk0.execute-api.us-east-1.amazonaws.com/dev"
        val path = "/roomlist"

        val req = Request.Builder().url(host + path).build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                response.use{
                    if (!response.isSuccessful) throw IOException("Unexpected code $response")
                    val str = response.body!!.string()
                    val items = ArrayList<CRoomList>()
                    //items.add(CRoomList("테스트", "test", "일반 렌주룰", 13))

                    try {
                        val jsonArray = JSONArray(str)
                        for (i in 0 until jsonArray.length()) {
                            val jsonObject = jsonArray.getJSONObject(i)
                            val roomHost = jsonObject.getString("host")
                            val roomGameMode = jsonObject.getInt("gamemode")
                            val roomTitle = jsonObject.getString("title")
                            val roomSize = jsonObject.getInt("size")

                            items.add(CRoomList(roomTitle, roomHost, roomGameMode, roomSize))
                        }
                    }catch(e: Exception) {
                    }

                    CoroutineScope(Dispatchers.Main).launch {
                        // 초기
                        // roomlist inflater
                        val myAdapter = CustomAdapterRoomList(applicationContext, items, this@WaitingRoomActivity)
                        val lvRoomList = findViewById<ListView>(R.id.listViewRoomList)
                        lvRoomList.adapter = myAdapter
                    }
                }
            }
        })
    }

    fun RoomJoin(host: String) {
        val client = OkHttpClient()
        val host = "https://k8q1jmufk0.execute-api.us-east-1.amazonaws.com/dev"
        val path = "/roomjoin"
        val RoomInfo = DataRoomEntry(username, usercode, host)

        val json = Gson().toJson(RoomInfo)
        val mediaType = "application/json; charset=utf-8".toMediaType()

        val req = Request.Builder().url(host + path).post(json.toString().toRequestBody(mediaType)).build()

        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!response.isSuccessful) throw IOException("Unexpected code $response")
                    val str = response.body!!.string()
                    val data = Gson().fromJson(str, DataRoomResponse::class.java)

                    if(data.success == true) {
                        CoroutineScope(Dispatchers.Main).launch {
                            this@WaitingRoomActivity.roomname = RoomInfo.host.toString()
                            val intent = Intent(this@WaitingRoomActivity, BoardActivity::class.java).apply {
                                putExtra(EXT_NAME, this@WaitingRoomActivity.username)
                                putExtra(EXT_CODE, this@WaitingRoomActivity.usercode)
                            }
                            startActivity(intent)
                        }
                    }
                }
            }
        })
    }
    fun GoBoard() {
        val intent = Intent(this, BoardActivity::class.java).apply {
            putExtra(EXT_NAME, username)
            putExtra(EXT_CODE, usercode)
        }
        startActivity(intent)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_waiting_room)

        // intent
        username = intent.getStringExtra(MainActivity.EXT_NAME).toString()
        usercode = intent.getIntExtra(MainActivity.EXT_CODE, -1)

        Log.d("print", "무야호 $username,$usercode" )

        // roomlist inflater
        val items = ArrayList<CRoomList>()
        //items.add(CRoomList("테스트", "test", 1, 13))
        val myAdapter = CustomAdapterRoomList(applicationContext, items, this)
        val lvRoomList = findViewById<ListView>(R.id.listViewRoomList)
        lvRoomList.adapter = myAdapter

        UpdateUser()
        UpdateRoom()

        val btnRoomUpdate = findViewById<Button>(R.id.buttonRoomUpdate)
        val btnRoomCreate = findViewById<Button>(R.id.buttonRoomCreate)
        val btnSoloPlay = findViewById<Button>(R.id.buttonSoloPlay)

        btnRoomUpdate.setOnClickListener {
            UpdateUser()
            UpdateRoom()
        }

        btnRoomCreate.setOnClickListener {
            GoBoard()
            val intent = Intent(this, CreateRoomActivity::class.java).apply {
                putExtra(EXT_NAME, username)
                putExtra(EXT_CODE, usercode)
            }
            startActivity(intent)
        }

        btnSoloPlay.setOnClickListener {
            GoBoard()
            val intent = Intent(this, CreateRoomActivity::class.java).apply {
                putExtra(EXT_NAME, username)
                putExtra(EXT_CODE, -usercode)
            }
            startActivity(intent)
        }
    }

}