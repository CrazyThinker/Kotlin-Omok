package edu.skku.cs.omok

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.*
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

class MainActivity : AppCompatActivity() {
    companion object {
        const val EXT_NAME = "user_name"
        const val EXT_CODE = "123456789"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val textViewUserName = findViewById<TextView>(R.id.editTextUserName)
        val textViewUserPassword = findViewById<TextView>(R.id.editTextUserPassword)
        val buttonSignIn = findViewById<Button>(R.id.buttonSignIn)
        val buttonNewId = findViewById<Button>(R.id.buttonNewId)

        val client = OkHttpClient()
        val host = "https://k8q1jmufk0.execute-api.us-east-1.amazonaws.com/dev"
        val path = "/login"

        // 로그인 버튼 클릭
        buttonSignIn.setOnClickListener {
            if (textViewUserName.length() == 0 || textViewUserPassword.length() == 0) {
                Toast.makeText(applicationContext,"아이디와 비밀번호를 입력해주세요.",Toast.LENGTH_SHORT).show()
            }
            else if(textViewUserName.length() > 10) {
                Toast.makeText(applicationContext,"아이디가 너무 깁니다.",Toast.LENGTH_SHORT).show()
            }
            else if(textViewUserName.length() > 20) {
                Toast.makeText(applicationContext,"비밀번호가 너무 깁니다.",Toast.LENGTH_SHORT).show()
            }
            else {
                val json = Gson().toJson(DataLogin(textViewUserName.text.toString(),textViewUserPassword.text.toString()))
                val mediaType = "application/json; charset=utf-8".toMediaType()

                val req = Request.Builder().url(host + path).post(json.toString().toRequestBody(mediaType)).build()
                client.newCall(req).enqueue(object : Callback {
                    override fun onFailure(call: Call, e: IOException) {
                        e.printStackTrace()
                    }

                    override fun onResponse(call: Call, response: Response) {
                        response.use {
                            if (!response.isSuccessful) throw IOException("Unexpected code $response")
                            val str = response.body!!.string()
                            val data = Gson().fromJson(str, DataLoginResponse::class.java)

                            if (data.login == true) {
                                CoroutineScope(Dispatchers.Main).launch {
                                    val intent = Intent(this@MainActivity, WaitingRoomActivity::class.java).apply {
                                        putExtra(EXT_NAME, textViewUserName.text.toString())
                                        putExtra(EXT_CODE, data.code)
                                    }
                                    startActivity(intent)
                                    // 에러날수도 있음
                                    //textViewUserName.text = ""
                                    //textViewUserPassword.text = ""
                                }
                            }
                            else {
                                CoroutineScope(Dispatchers.Main).launch {
                                    Toast.makeText(applicationContext,"아이디 혹은 비밀번호를 잘못 입력했습니다.",Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                })
            }
        }

        // 회원가입 버튼 클릭
        buttonNewId.setOnClickListener {
            val intent = Intent(this@MainActivity, NewIdActivity::class.java)
            startActivity(intent)

            textViewUserName.text = ""
            textViewUserPassword.text = ""
        }
    }
}