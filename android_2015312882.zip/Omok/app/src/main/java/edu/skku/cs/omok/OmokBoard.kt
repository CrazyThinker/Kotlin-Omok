package edu.skku.cs.omok

class OmokBoard {
    var Size = 13
    var Board = Array(21) { IntArray(21) }
    var Ban = Array(21) { IntArray(21) }
    var Order = Array(21) { IntArray(21) }
    var Player1Stone = 1
    var Turn = 1
    var NextStone = 1

    private val Dir_x = arrayOf(-1, 1, 0, 0, -1, 1, -1, 1)
    private val Dir_y = arrayOf(0, 0, -1, 1, -1, 1, 1, -1)

    fun ClearBoard(size: Int) {
        Size = size
        NextStone = 1

        Player1Stone = 1
        Turn = 1

        for (i in 0..Size + 1) {
            for(j in 0..Size + 1) {
                if(1 in 1..Size && j in 1..Size) {
                    Board[i][j] = 0
                    Ban[i][j] = 0
                }
                else {
                    Board[i][j] = -1
                }
            }
        }
    }

    fun Place(x:Int, y:Int, stone: Int) {
        Board[x][y] = stone
    }

    fun FindEmpty(x: Int, y: Int, stone: Int, dir: Int): Array<Int> {
        var X = x
        var Y = y

        while(X in 1..Size && Y in 1..Size && Board[X][Y] == stone) {
            X += Dir_x[dir]
            Y += Dir_y[dir]
        }

        return arrayOf(X, Y)
    }

    fun GetCount(x: Int, y: Int, stone: Int, dir: Int): Int {

        var X = x
        var Y = y
        var Count = 0

        if(Board[x][y] != 0) {
            return 0
        }

        Place(x, y, stone)

        while(X in 1..Size && Y in 1..Size && Board[X][Y] == stone) {
            X += Dir_x[dir]
            Y += Dir_y[dir]
            Count++
        }

        var rdir = dir + (dir + 1) % 2 * 2 - 1

        X = x + Dir_x[rdir]
        Y = y + Dir_y[rdir]
        while(X in 1..Size && Y in 1..Size && Board[X][Y] == stone) {
            X += Dir_x[rdir]
            Y += Dir_y[rdir]
            Count++
        }

        Place(x, y, 0)

        return Count
    }

    fun IsFive(x: Int, y: Int, stone: Int): Boolean {
        for(i in 0 until 8 step 2) {
            if(GetCount(x, y, stone, i) == 5) return true
        }
        return false
    }

    fun IsFive(x: Int, y: Int, stone: Int, dir: Int): Boolean {
        if(GetCount(x, y, stone, dir) == 5) return true
        return false
    }

    fun IsSix(x: Int, y: Int, stone: Int): Boolean {
        for(i in 0 until 8 step 2) {
            if(GetCount(x, y, stone, i) >= 6) return true
        }
        return false
    }

    fun IsFour(x: Int, y: Int, stone: Int, dir: Int): Boolean {
        var rdir = dir - dir % 2

        Place(x, y, stone)
        for(i in 0..1) {
            var X = x
            var Y = y

            val Point = FindEmpty(X, Y, stone, rdir + i)
            if (Board[Point[0]][Point[1]] == 0) {
                if (IsFive(Point[0], Point[1], rdir + i)) {
                    Place(x, y, 0)
                    return true
                }
            }
        }
        Place(x, y, 0)
        return false
    }

    fun IsOpenFour(x: Int, y: Int, stone: Int, dir: Int): Int {
        var rdir = dir - dir % 2
        var sum = 0

        Place(x, y, stone)
        for(i in 0..1) {
            var X = x
            var Y = y

            val Point = FindEmpty(X, Y, stone, rdir + i)
            if (Board[Point[0]][Point[1]] == 0) {
                if (IsFive(Point[0], Point[1], stone, rdir + i)) {
                    sum++
                }
            }
        }
        Place(x, y, 0)

        if(sum == 2 && GetCount(x, y, stone, rdir) == 4) sum = 1
        else sum = 0

        return sum
    }

    fun IsDoubleFour(x: Int, y: Int, stone: Int): Boolean {
        var Count = 0
        for(i in 0 until 8 step 2) {
            if(IsOpenFour(x, y, stone, i) == 2) return true
            else if(IsFour(x, y, stone, i)) {
                Count++

                if (Count >= 2) return true
            }
        }

        return false
    }


    fun IsOpenThree(x: Int, y: Int, stone: Int, dir: Int): Boolean {
        Place(x, y, stone)

        for (i in 0..1) {
            var X = x
            var Y = y

            val Point = FindEmpty(X, Y, stone, dir + i)
            if (Board[Point[0]][Point[1]] == 0) {
                if(IsOpenFour(Point[0], Point[1], stone, dir + i) == 1 && (!IsForbidden(Point[0], Point[1], stone))) {
                    Place(x, y, 0)
                    return true
                }
            }
        }
        Place(x, y, 0)
        return false
    }

    fun IsDoubleThree(x: Int, y: Int, stone: Int): Boolean {
        var Count = 0

        for(i in 0 until 8 step 2) {
            if(IsOpenThree(x, y, stone, i)) {
                Count++
                if(Count >= 2) return true
            }
        }
        return false
    }

    fun IsForbidden(x: Int, y: Int, stone: Int): Boolean {
        if(IsDoubleFour(x, y, stone)) return true
        else if(IsDoubleThree(x, y, stone)) return true
        else if(IsSix(x, y, stone)) return true
        else return false
    }

    fun CalculateBan(stone: Int) {
        for(i in 1..Size) {
            for(j in 1..Size) {
                if(Board[i][j] == 0) {
                    if (stone == 2) {
                        Ban[i][j] = 0
                    }
                    else {
                        Place(i, j, stone)
                        if (IsForbidden(i, j, stone)) Ban[i][j] = 1
                        else Ban[i][j] = 0
                        Place(i, j, 0)
                    }
                }
            }
        }
    }
}