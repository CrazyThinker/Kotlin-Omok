package edu.skku.cs.omok

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

class NewIdActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_id)

        val textViewUserNewName = findViewById<TextView>(R.id.editTextUserNewName)
        val textViewUserNewPassword = findViewById<TextView>(R.id.editTextUserNewPassword)
        val textViewUserNewRepeatPassword = findViewById<TextView>(R.id.editTextUserNewRepeatPassword)
        val buttonNewID = findViewById<Button>(R.id.buttonNewID)

        val client = OkHttpClient()
        val host = "https://k8q1jmufk0.execute-api.us-east-1.amazonaws.com/dev"
        val path = "/newid"

        // 회원가입 버튼 클릭
        buttonNewID.setOnClickListener {
            if (textViewUserNewName.text.length == 0 || textViewUserNewPassword.text.length == 0) {
                Toast.makeText(applicationContext,"아이디와 비밀번호를 입력해주세요.", Toast.LENGTH_SHORT).show()
            }
            else if(textViewUserNewName.text.length > 10) {
                Toast.makeText(applicationContext,"아이디가 너무 깁니다.",Toast.LENGTH_SHORT).show()
            }
            else if(textViewUserNewPassword.text.length > 20) {
                Toast.makeText(applicationContext,"비밀번호가 너무 깁니다.",Toast.LENGTH_SHORT).show()
            }
            else if(textViewUserNewPassword.text.toString() != textViewUserNewRepeatPassword.text.toString()) {
                Toast.makeText(applicationContext,"동일한 비밀번호를 입력하세요.", Toast.LENGTH_SHORT).show()
            }
            else {
                val json = Gson().toJson(DataNewId(textViewUserNewName.text.toString(),textViewUserNewPassword.text.toString()))
                val mediaType = "application/json; charset=utf-8".toMediaType()

                val req = Request.Builder().url(host + path).post(json.toString().toRequestBody(mediaType)).build()
                client.newCall(req).enqueue(object : Callback {
                    override fun onFailure(call: Call, e: IOException) {
                        e.printStackTrace()
                    }

                    override fun onResponse(call: Call, response: Response) {
                        response.use {
                            if (!response.isSuccessful) throw IOException("Unexpected code $response")
                            val str = response.body!!.string()
                            val data = Gson().fromJson(str, DataNewIdResponse::class.java)

                            if (data.success == true) {
                                CoroutineScope(Dispatchers.Main).launch {
                                    Toast.makeText(applicationContext,"아이디를 생성했습니다.",Toast.LENGTH_SHORT).show()
                                    finish()
                                }
                            }
                            else {
                                CoroutineScope(Dispatchers.Main).launch {
                                    Toast.makeText(applicationContext,"아이디 생성에 실패했습니다.",Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                })
            }
        }
    }
}