package edu.skku.cs.omok

import android.app.AlertDialog
import android.app.PendingIntent.OnFinished
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import java.io.IOException
import kotlin.random.Random

class BoardActivity : AppCompatActivity() {
    var username = ""
    var usercode = 0
    var host = ""
    var gamemode = 0

    var Board: OmokBoard = OmokBoard()

    fun BoardUpdate() {
        val boardView = findViewById<BoardView>(R.id.boardView)

        for(x in 1..Board.Size) {
            for(y in 1..Board.Size) {
                boardView.Board.Board[x][y] = Board.Board[x][y]
                boardView.Board.Ban[x][y] = Board.Ban[x][y]
            }
        }
    }

    fun StonePlace(x: Int, y: Int): Boolean { // 바둑돌 검사하고 놓는 함수
        if(Board.Board[x][y] != 0 || Board.Ban[x][y] == 1) return false

        Board.Place(x, y, Board.NextStone)

        if(CalculateWin(x, y, Board.NextStone)) return true

        Board.Place(x, y, Board.NextStone)

        if(gamemode == -1) { // 일반 렌주룰
        }
        else if(gamemode == -2) { // 오프닝 렌주룰 (Swap 룰)
            if(Board.Turn == 3) {
                val alertDialog = AlertDialog.Builder(this)
                    .setTitle("확인")
                    .setMessage("선공권을 바꾸시겠습니까?")
                    .setPositiveButton("예") { dialog, _ ->
                        dialog.dismiss()

                        val ivp1 = findViewById<ImageView>(R.id.imageViewPlayer1)
                        val ivp2 = findViewById<ImageView>(R.id.imageViewPlayer2)

                        Board.Player1Stone = Board.Player1Stone % 2 + 1
                        if (Board.Player1Stone == 1) {
                            ivp1.setImageResource(R.drawable.stone_black)
                            ivp2.setImageResource(R.drawable.stone_white)
                        }
                        else {
                            ivp1.setImageResource(R.drawable.stone_white)
                            ivp2.setImageResource(R.drawable.stone_black)
                        }

                        val tvTurn = findViewById<TextView>(R.id.textViewTurn)
                        if (Board.Player1Stone == Board.NextStone) tvTurn.text = "◀                                                  "
                        else tvTurn.text = "                                                  ▶"
                    }
                    .setNegativeButton("아니오") { dialog, _ ->
                        dialog.dismiss()
                    }
                    .create()

                alertDialog.show()
            }
            else if(Board.Turn < 3) {
                Board.Player1Stone = Board.Player1Stone % 2 + 1
            }
        }
        else if(gamemode == -3) { // 오프닝 렌주룰 (Swap 2 룰)
            if(Board.Turn == 3 || Board.Turn == 5) {
                val alertDialog = AlertDialog.Builder(this)
                    .setTitle("확인")
                    .setMessage("선공권을 바꾸시겠습니까?")
                    .setPositiveButton("예") { dialog, _ ->
                        dialog.dismiss()

                        val ivp1 = findViewById<ImageView>(R.id.imageViewPlayer1)
                        val ivp2 = findViewById<ImageView>(R.id.imageViewPlayer2)

                        Board.Player1Stone = Board.Player1Stone % 2 + 1
                        if (Board.Player1Stone == 1) {
                            ivp1.setImageResource(R.drawable.stone_black)
                            ivp2.setImageResource(R.drawable.stone_white)
                        }
                        else {
                            ivp1.setImageResource(R.drawable.stone_white)
                            ivp2.setImageResource(R.drawable.stone_black)
                        }

                        val tvTurn = findViewById<TextView>(R.id.textViewTurn)
                        if (Board.Player1Stone == Board.NextStone) tvTurn.text = "◀                                                  "
                        else tvTurn.text = "                                                  ▶"
                    }
                    .setNegativeButton("아니오") { dialog, _ ->
                        dialog.dismiss()
                    }
                    .create()

                alertDialog.show()
            }
            else if(Board.Turn < 3) {
                Board.Player1Stone = Board.Player1Stone % 2 + 1
            }
        }
        else if(gamemode == -4) { // 오프닝 렌주룰 (taranikov 룰)
            if(Board.Turn == 2 || Board.Turn == 3) {
                val alertDialog = AlertDialog.Builder(this)
                    .setTitle("확인")
                    .setMessage("선공권을 바꾸시겠습니까?")
                    .setPositiveButton("예") { dialog, _ ->
                        dialog.dismiss()

                        val ivp1 = findViewById<ImageView>(R.id.imageViewPlayer1)
                        val ivp2 = findViewById<ImageView>(R.id.imageViewPlayer2)

                        Board.Player1Stone = Board.Player1Stone % 2 + 1
                        if (Board.Player1Stone == 1) {
                            ivp1.setImageResource(R.drawable.stone_black)
                            ivp2.setImageResource(R.drawable.stone_white)
                        }
                        else {
                            ivp1.setImageResource(R.drawable.stone_white)
                            ivp2.setImageResource(R.drawable.stone_black)
                        }

                        val tvTurn = findViewById<TextView>(R.id.textViewTurn)
                        if (Board.Player1Stone == Board.NextStone) tvTurn.text = "◀                                                  "
                        else tvTurn.text = "                                                  ▶"
                    }
                    .setNegativeButton("아니오") { dialog, _ ->
                        dialog.dismiss()
                    }
                    .create()

                alertDialog.show()
            }
        }
        Board.Order[x][y] = Board.Turn++
        Board.NextStone = Board.NextStone % 2 + 1

        Board.CalculateBan(Board.NextStone)
        BoardUpdate()

        Log.d("print", "${Board.Player1Stone}, ${Board.NextStone}, ${Board.Turn}")
        val tvTurn = findViewById<TextView>(R.id.textViewTurn)
        if (Board.Player1Stone == Board.NextStone) tvTurn.text = "◀                                                  "
        else tvTurn.text = "                                                  ▶"

        return true
    }

    fun CalculateWin(x: Int, y: Int, stone: Int): Boolean {
        if(stone == 1 && (Board.IsFive(x, y, stone) || Board.IsSix(x, y, stone)) || stone == 2 && ((Board.IsFive(x, y, stone) && !Board.IsSix(x, y, stone)))) {
            val player = 1 + stone != Board.Player1Stone
            val alertDialog = AlertDialog.Builder(this)
                .setTitle("축하드립니다!")
                .setMessage("Player ${player}이 이겼습니다!")
                .create()

            alertDialog.show()
            return true
        }
        return false
    }

    fun GameStart() {
        val ivp1 = findViewById<ImageView>(R.id.imageViewPlayer1)
        val ivp2 = findViewById<ImageView>(R.id.imageViewPlayer2)

        Board.Player1Stone = Random.nextInt(1, 3)
        val tvTurn = findViewById<TextView>(R.id.textViewTurn)
        if (Board.Player1Stone == 1) {
            tvTurn.text = "◀                                                  "
            ivp1.setImageResource(R.drawable.stone_black)
            ivp2.setImageResource(R.drawable.stone_white)
        }
        else {
            tvTurn.text = "                                                  ▶"
            ivp1.setImageResource(R.drawable.stone_white)
            ivp2.setImageResource(R.drawable.stone_black)
        }
    }

    fun RoomLeave() {
        val RoomInfo = DataRoomEntry(username, usercode, host)
        val client = OkHttpClient()
        val host = "https://k8q1jmufk0.execute-api.us-east-1.amazonaws.com/dev"
        val path = "/roomleave"

        val json = Gson().toJson(RoomInfo)
        val mediaType = "application/json; charset=utf-8".toMediaType()

        val req = Request.Builder().url(host + path).post(json.toString().toRequestBody(mediaType)).build()

        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_board)

        // intent
        username = intent.getStringExtra(MainActivity.EXT_NAME).toString()
        usercode = intent.getIntExtra(MainActivity.EXT_CODE, -1)

        val boardView: BoardView = findViewById<BoardView>(R.id.boardView)
        boardView.Board.Size = Board.Size
        boardView.Board.Turn = Board.Turn
        Board.ClearBoard(Board.Size)
        BoardUpdate()

        // 착수 버튼
        val btnPlace = findViewById<Button>(R.id.buttonPlace)
        btnPlace.setOnClickListener {
            val CursorX = boardView.CursorX
            val CursorY = boardView.CursorY

            if (CursorX in 1..Board.Size && CursorY in 1..Board.Size) {
                if(StonePlace(CursorX, CursorY)) {
                    BoardUpdate()
                    boardView.CursorX = 0
                    boardView.CursorY = 0
                    boardView.invalidate()
                }
            }
        }

        // 방 정보
        val client = OkHttpClient()
        val host = "https://k8q1jmufk0.execute-api.us-east-1.amazonaws.com/dev/room?host="
        val path = username

        val req = Request.Builder().url(host + path).build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                response.use{
                    if (!response.isSuccessful) throw IOException("Unexpected code $response")
                    val str = response.body!!.string()
                    val data = Gson().fromJson(str, DataRoomInfoResponse::class.java)

                    CoroutineScope(Dispatchers.Main).launch {
                        Log.d("print", "test good, ${gamemode}")
                        Board.Size = data.size!!
                        Board.Size = 13
                        gamemode = data.gamemode!!
                        Board.ClearBoard(Board.Size)
                        this@BoardActivity.host = data.challenger.toString()

                        val boardView: BoardView = findViewById<BoardView>(R.id.boardView)
                        boardView.invalidate()

                        if(gamemode < 0) GameStart()
                    }
                }
            }
        })
    }

    override fun onDestroy() {
        super.onDestroy()

        RoomLeave()
    }
}
