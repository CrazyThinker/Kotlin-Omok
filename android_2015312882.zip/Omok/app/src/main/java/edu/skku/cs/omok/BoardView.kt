package edu.skku.cs.omok

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat

class BoardView(context: Context, attrs: AttributeSet) : View(context, attrs) {
    private val linePaint = Paint()
    private val stoneBlackDrawable: Drawable?
    private val stoneWhiteDrawable: Drawable?
    private val cursorPaint = Paint()
    private val banCirclePaint = Paint()

    var Board: OmokBoard = OmokBoard()

    // 커서
    var CursorX = 0
    var CursorY = 0

    init {

        // 줄무늬
        linePaint.color = Color.BLACK
        linePaint.style = Paint.Style.STROKE
        linePaint.strokeWidth = 3f

        // 커서
        cursorPaint.color = Color.parseColor("#F82104")
        cursorPaint.style = Paint.Style.STROKE
        cursorPaint.strokeWidth = 5f
        cursorPaint.isAntiAlias = true

        // 돌
        stoneBlackDrawable = ContextCompat.getDrawable(context, R.drawable.stone_black)
        stoneWhiteDrawable = ContextCompat.getDrawable(context, R.drawable.stone_white)

        // 금수
        banCirclePaint.color = Color.RED
        banCirclePaint.style = Paint.Style.FILL

        setOnTouchListener(object : View.OnTouchListener {
            override fun onTouch(view: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                        // 클릭한 위치의 좌표값을 가져옵니다.
                        val x = event.y
                        val y = event.x
                        val view_x = width
                        val view_y = height

                        // CursorX와 CursorY 값을 수정합니다.
                        CursorX = (x / view_x * (Board.Size + 1) + 0.5).toInt()
                        CursorY = (y / view_y * (Board.Size + 1) + 0.5).toInt()

                        // View를 다시 그리도록 요청합니다.
                        invalidate()
                    }
                }
                return true
            }
        })
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val width = width.toFloat()
        val height = height.toFloat()
        // 줄무늬 간격
        val interval = width / (Board.Size + 1)

        // 가로줄 그리기
        for (i in 1..Board.Size) {
            val y = i * interval
            canvas.drawLine(interval, y, width - interval, y, linePaint)
        }

        // 세로줄 그리기
        for (i in 1..Board.Size) {
            val x = i * interval
            canvas.drawLine(x, interval, x, height - interval, linePaint)
        }

        // 돌 그리기
        val stoneSize = (interval.coerceAtMost(interval) * 0.8).toInt() // 돌 크기
        for (x in 1..Board.Size) {
            for (y in 1..Board.Size) {
                val stoneX = (interval * x - stoneSize / 2).toFloat()
                val stoneY = (interval * y - stoneSize / 2).toFloat()

                if(Board.Board[x][y] == 0) { // 비어있음

                }
                else if(Board.Board[x][y] % 2 == 1) { // 검은돌
                    stoneBlackDrawable?.setBounds(
                        stoneY.toInt(),
                        stoneX.toInt(),
                        (stoneY + stoneSize).toInt(),
                        (stoneX + stoneSize).toInt()
                    )
                    stoneBlackDrawable?.draw(canvas)
                }
                else if(Board.Board[x][y] % 2 == 0) { // 흰돌
                    stoneWhiteDrawable?.setBounds(
                        stoneY.toInt(),
                        stoneX.toInt(),
                        (stoneY + stoneSize).toInt(),
                        (stoneX + stoneSize).toInt()
                    )
                    stoneWhiteDrawable?.draw(canvas)
                }
            }
        }

        // 커서 그리기
        if (CursorX in 1..Board.Size && CursorY in 1..Board.Size) {
            val cursorX = (interval * CursorX).toFloat()
            val cursorY = (interval * CursorY).toFloat()
            val cursorSize = (stoneSize * 1.2).toInt() // 커서 크기
            val cursorRect = RectF(
                cursorY - cursorSize / 2,
                cursorX - cursorSize / 2,
                cursorY + cursorSize / 2,
                cursorX + cursorSize / 2
            )
            canvas.drawRect(cursorRect, cursorPaint)

        }

        val banCircleRadius = (interval * 0.2).toFloat() // 작은 동그라미 반지름
        // 금수자리 그리기
        for (x in 1..Board.Size) {
            for (y in 1..Board.Size) {
                if (Board.Ban[x][y] == 1) {
                    val circleX = (interval * x)
                    val circleY = (interval * y)
                    canvas.drawCircle(circleY, circleX, banCircleRadius, banCirclePaint)
                }
            }
        }
    }
}