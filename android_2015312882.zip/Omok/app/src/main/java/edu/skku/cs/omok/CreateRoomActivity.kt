package edu.skku.cs.omok

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

class CreateRoomActivity : AppCompatActivity() {
    companion object {
        const val EXT_NAME = "user_name"
        const val EXT_CODE = "123456789"
    }

    var username = ""
    var usercode = 0
    var modesolo = 1

    fun RoomCreate(RoomInfo: DataRoomCreate) {
        val client = OkHttpClient()
        val host = "https://k8q1jmufk0.execute-api.us-east-1.amazonaws.com/dev"
        val path = "/roomcreate"

        val json = Gson().toJson(RoomInfo)
        val mediaType = "application/json; charset=utf-8".toMediaType()

        val req = Request.Builder().url(host + path).post(json.toString().toRequestBody(mediaType)).build()

        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!response.isSuccessful) throw IOException("Unexpected code $response")
                    val str = response.body!!.string()
                    val data = Gson().fromJson(str, DataRoomResponse::class.java)

                    if(data.success == true) {
                        CoroutineScope(Dispatchers.Main).launch {
                            finish()
                        }
                    }
                }
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_room)

        username = intent.getStringExtra(MainActivity.EXT_NAME).toString()
        usercode = intent.getIntExtra(MainActivity.EXT_CODE, -1)

        Log.d("print", "무야호오 $username,$usercode" )

        Log.d("print", "$usercode, $modesolo")
        if(usercode < 0) {
            usercode *= -1
            modesolo = -1
        }
        Log.d("print", "$usercode, $modesolo")

        val tvRoomTitle = findViewById<EditText>(R.id.editTextRoomTitle)
        val sbBoardSize = findViewById<SeekBar>(R.id.seekBarBoardSize)
        val rgGameMode = findViewById<RadioGroup>(R.id.RadioGroupGameMode)
        val btnCreateRoom = findViewById<Button>(R.id.buttonCreateRoom)

        btnCreateRoom.setOnClickListener {
            val selectedRadioButtonId = rgGameMode.checkedRadioButtonId

            if(selectedRadioButtonId != -1) {
                var gamemode = 0
                val selectedRadioButton = findViewById<RadioButton>(selectedRadioButtonId)
                val selectedOption = selectedRadioButton.text.toString()

                if(selectedOption == "일반 렌주룰") gamemode = 1
                else if(selectedOption == "오프닝 렌주룰 (Swap 룰)") gamemode = 2

                Log.d("print", "$usercode, $modesolo")
                gamemode *= modesolo

                RoomCreate(DataRoomCreate(username, usercode, sbBoardSize.progress, gamemode, tvRoomTitle.text.toString()))
            }
            else {
                Toast.makeText(this, "게임 모드를 선택해주세요.", Toast.LENGTH_SHORT).show()
            }
        }

    }
}
