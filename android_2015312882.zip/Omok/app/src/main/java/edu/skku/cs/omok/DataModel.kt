package edu.skku.cs.omok

data class DataLogin(var name: String ?= null, var password: String ?= null)
data class DataLoginResponse(var login: Boolean ?= null, var code:Int ?= null)

data class DataNewId(var name: String ?= null, var password: String ?= null)
data class DataNewIdResponse(var success: Boolean ?= null)

data class DataUserInfoResponse(var win: Int ?= null, var lose: Int ?= null)

data class DataRoomEntry(var name: String ?= null, var code: Int ?= null, var host: String ?= null)
data class DataRoomCreate(var name: String ?= null, var code: Int, var size: Int ?= null, var gamemode: Int ?= null, var title: String ?= null)
data class DataRoomResponse(var success: Boolean ?= null)
data class DataRoomInfoResponse(var challenger: String ?= null, var size: Int ?= null, var gamemode: Int ?= null, var title: String ?= null, var host: String ?= null)
